<?php 
//Retrieve Theme Options Data
global $options;
$options = get_option('pupul_theme_options');

//Add Theme Options File
require_once ('functions/theme-options.php');

//Redirect to Theme Options Page on Activation
if ( is_admin() && isset($_GET['activated'] ) && $pagenow =="themes.php" )
	wp_redirect( 'admin.php?page=theme-options.php' );
 ?>
<?php
if ( ! isset( $content_width ) )
	$content_width = 640;
/** Tell WordPress to run pupul_setup() when the 'after_setup_theme' hook is run. */
add_action( 'after_setup_theme', 'pupul_setup' );

if ( ! function_exists( 'pupul_setup' ) ):
function pupul_setup() {

	// This theme styles the visual editor with editor-style.css to match the theme style.
	add_editor_style();

	// Post Format support. You can also use the legacy "gallery" or "asides" (note the plural) categories.
	add_theme_support( 'post-formats', array( 'aside', 'gallery' ) );

	// This theme uses post thumbnails
	add_theme_support( 'post-thumbnails' );

	// Add default posts and comments RSS feed links to head
	add_theme_support( 'automatic-feed-links' );
	
	// This theme uses wp_nav_menu() in one location.
	register_nav_menus( array(
		'primary' => __( 'Primary Navigation', 'pupul' ),
	) );
// custom admin login logo
function pupul_login_logo() {
	echo '<style type="text/css">
	h1 a { background-image: url('.get_bloginfo('template_directory').'/logo.png) !important; }
	</style>';
}
add_action('login_head', 'pupul_login_logo');

/** Custom Login Link **/
function pupul_login_logo_url() {
    return home_url();
}
add_filter( 'login_headerurl', 'pupul_login_logo_url' );

function pupul_login_logo_url_title() {
    return get_bloginfo('title');
}
add_filter( 'login_headertitle', 'pupul_login_logo_url_title' );
}
function pupul_login_stylesheet() { ?>
    <link rel="stylesheet" id="pupul_wp_admin_css"  href="<?php echo get_stylesheet_directory_uri() . '/style-login.css'; ?>" type="text/css" media="all" />
<?php }
add_action( 'login_enqueue_scripts', 'pupul_login_stylesheet' );
{
?>
<?php
}
endif;

function pupul_page_menu_args( $args ) {
	$args['show_home'] = true;
	return $args;
}
add_filter( 'wp_page_menu_args', 'pupul_page_menu_args' );

function pupul_excerpt_length( $length ) {
	return 40;
}
add_filter( 'excerpt_length', 'pupul_excerpt_length' );

// WP Title
 function pupul_filter_wp_title( $title ) {
	if ( is_feed() )
		return "$title";
    // Get the Site Name
    $site_name = bloginfo( 'name' );
	// Add the blog description for the home/front page
	$site_description = get_bloginfo( 'description', 'display' );
	if ( $site_description && ( is_home() || is_front_page() ) )
		echo " &#187; $site_description";
	// Add a page number if necessary:
		global $page, $paged;
	if ( $paged >= 2 || $page >= 2 )
		echo ' &#187; ' . sprintf( __( 'Page %s', 'pupul' ), max( $paged, $page ) );
    // Prepend name
    $filtered_title = $title;
    // Return the modified title
    return $filtered_title;
}
add_filter( 'wp_title', 'pupul_filter_wp_title' );

/**
 * Returns a "Continue Reading" link for excerpts
 * @since Pupul 1.0
 * @return string "Continue Reading" link
 */
function pupul_continue_reading_link() {
	return ' <a href="'. get_permalink() . '">' . __( 'read more <span class="meta-nav">&#187;</span>', 'pupul' ) . '</a>';
}

function pupul_auto_excerpt_more( $more ) {
	return ' &hellip;' . pupul_continue_reading_link();
}
add_filter( 'excerpt_more', 'pupul_auto_excerpt_more' );

/**
 * Adds a pretty "Continue Reading" link to custom post excerpts.
 */
function pupul_custom_excerpt_more( $output ) {
	if ( has_excerpt() && ! is_attachment() ) {
		$output .= pupul_continue_reading_link();
	}
	return $output;
}
add_filter( 'get_the_excerpt', 'pupul_custom_excerpt_more' );

add_filter( 'use_default_gallery_style', '__return_false' );

function pupul_remove_gallery_css( $css ) {
	return preg_replace( "#<style type='text/css'>(.*?)</style>#s", '', $css );
}
// Backwards compatibility with WordPress 3.3.
if ( version_compare( $GLOBALS['wp_version'], '3.4', '<' ) )
	add_filter( 'gallery_style', 'pupul_remove_gallery_css' );

if ( ! function_exists( 'pupul_comment' ) ) :
function pupul_comment( $comment, $args, $depth ) {
	$GLOBALS['comment'] = $comment;
	switch ( $comment->comment_type ) :
		case '' :
	?>
	<li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>">
		<div id="comment-<?php comment_ID(); ?>">
		<div class="comment-author vcard">
			<?php echo get_avatar( $comment, 40 ); ?>
			<?php printf( __( '%s <span class="says">says:</span>', 'pupul' ), sprintf( '<cite class="fn">%s</cite>', get_comment_author_link() ) ); ?>
		</div><!-- .comment-author .vcard -->
		<?php if ( $comment->comment_approved == '0' ) : ?>
			<em class="comment-awaiting-moderation"><?php _e( 'Your comment is awaiting moderation.', 'pupul' ); ?></em>
			<br />
		<?php endif; ?>

		<div class="comment-meta commentmetadata"><a href="<?php echo esc_url( get_comment_link( $comment->comment_ID ) ); ?>">
			<?php
				/* translators: 1: date, 2: time */
				printf( __( '%1$s at %2$s', 'pupul' ), get_comment_date(),  get_comment_time() ); ?></a><?php edit_comment_link( __( '(Edit)', 'pupul' ), ' ' );
			?>
		</div><!-- .comment-meta .commentmetadata -->

		<div class="comment-body"><?php comment_text(); ?></div>

		<div class="reply">
			<?php comment_reply_link( array_merge( $args, array( 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>
		</div><!-- .reply -->
	</div><!-- #comment-##  -->

	<?php
			break;
		case 'pingback'  :
		case 'trackback' :
	?>
	<li class="post pingback">
		<p><?php _e( 'Pingback:', 'pupul' ); ?> <?php comment_author_link(); ?><?php edit_comment_link( __( '(Edit)', 'pupul' ), ' ' ); ?></p>
	<?php
			break;
	endswitch;
}
endif;

function pupul_widgets_init() {
	// Area 1, located at the top of the sidebar.
	register_sidebar( array(
		'name' => __( 'Primary Widget Area', 'pupul' ),
		'id' => 'primary-widget-area',
		'description' => __( 'The primary widget area', 'pupul' ),
		'before_widget' => '<li id="%1$s" class="widget-container %2$s">',
		'after_widget' => '</li>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );

	// Area 2, located below the Primary Widget Area in the sidebar. Empty by default.
	register_sidebar( array(
		'name' => __( 'Secondary Widget Area', 'pupul' ),
		'id' => 'secondary-widget-area',
		'description' => __( 'The secondary widget area', 'pupul' ),
		'before_widget' => '<li id="%1$s" class="widget-container %2$s">',
		'after_widget' => '</li>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );

	// Area 3, located in the footer. Empty by default.
	register_sidebar( array(
		'name' => __( 'First Footer Widget Area', 'pupul' ),
		'id' => 'first-footer-widget-area',
		'description' => __( 'The first footer widget area', 'pupul' ),
		'before_widget' => '<li id="%1$s" class="widget-container %2$s">',
		'after_widget' => '</li>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );

	// Area 4, located in the footer. Empty by default.
	register_sidebar( array(
		'name' => __( 'Second Footer Widget Area', 'pupul' ),
		'id' => 'second-footer-widget-area',
		'description' => __( 'The second footer widget area', 'pupul' ),
		'before_widget' => '<li id="%1$s" class="widget-container %2$s">',
		'after_widget' => '</li>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );

	// Area 5, located in the footer. Empty by default.
	register_sidebar( array(
		'name' => __( 'Third Footer Widget Area', 'pupul' ),
		'id' => 'third-footer-widget-area',
		'description' => __( 'The third footer widget area', 'pupul' ),
		'before_widget' => '<li id="%1$s" class="widget-container %2$s">',
		'after_widget' => '</li>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );

	// Area 6, located in the footer. Empty by default.
	register_sidebar( array(
		'name' => __( 'Fourth Footer Widget Area', 'pupul' ),
		'id' => 'fourth-footer-widget-area',
		'description' => __( 'The fourth footer widget area', 'pupul' ),
		'before_widget' => '<li id="%1$s" class="widget-container %2$s">',
		'after_widget' => '</li>',
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );
}
/** Register sidebars by running pupul_widgets_init() on the widgets_init hook. */
add_action( 'widgets_init', 'pupul_widgets_init' );

function pupul_remove_recent_comments_style() {
	add_filter( 'show_recent_comments_widget_style', '__return_false' );
}
add_action( 'widgets_init', 'pupul_remove_recent_comments_style' );

if ( ! function_exists( 'pupul_posted_on' ) ) :
/**
 * Prints HTML with meta information for the current post-date/time and author.
 *
 * @since Pupul 1.0
 */
function pupul_posted_on() {
	printf( __( '<span class="%1$s">Posted on</span> %2$s <span class="meta-sep">by</span> %3$s', 'pupul' ),
		'meta-prep meta-prep-author',
		sprintf( '<a href="%1$s" title="%2$s" rel="bookmark"><span class="entry-date">%3$s</span></a>',
			get_permalink(),
			esc_attr( get_the_time() ),
			get_the_date()
		),
		sprintf( '<span class="author vcard"><a class="url fn n" href="%1$s" title="%2$s">%3$s</a></span>',
			get_author_posts_url( get_the_author_meta( 'ID' ) ),
			sprintf( esc_attr__( 'View all posts by %s', 'pupul' ), get_the_author() ),
			get_the_author()
		)
	);
}
endif;

if ( ! function_exists( 'pupul_posted_in' ) ) :
function pupul_posted_in() {
	// Retrieves tag list of current post, separated by commas.
	$tag_list = get_the_tag_list( '', ', ' );
	if ( $tag_list ) {
		$posted_in = __( 'This entry was posted in %1$s and tagged %2$s. Bookmark the <a href="%3$s" title="Permalink to %4$s" rel="bookmark">permalink</a>.', 'pupul' );
	} elseif ( is_object_in_taxonomy( get_post_type(), 'category' ) ) {
		$posted_in = __( 'This entry was posted in %1$s. Bookmark the <a href="%3$s" title="Permalink to %4$s" rel="bookmark">permalink</a>.', 'pupul' );
	} else {
		$posted_in = __( 'Bookmark the <a href="%3$s" title="Permalink to %4$s" rel="bookmark">permalink</a>.', 'pupul' );
	}
	// Prints the string, replacing the placeholders.
	printf(
		$posted_in,
		get_the_category_list( ', ' ),
		$tag_list,
		get_permalink(),
		the_title_attribute( 'echo=0' )
	);
}
endif;
