=== Pupul Readme (readme.txt) ===
* This file was introduced with version 1.0 of Pupul and will be maintained with future releases. The following information may be found and/or updated as needed:

== Contents ==
* Basic FAQ
* Notes
* Changelog

== Basic FAQ ==
= Q: How to change the logo? =
A: See theme options page.

= Q: Does the theme support multi-level drop-down menus?
A: Yes

= Q: Does the theme support footer widget? =
A: Yes, But this is by default not enabled. You can access it in widgets.

== Notes ==
* Custom Dropdown menu works when customized.

== Changelog ==
* This is the 3nd version
