<?php ?>
	</div><!-- #main -->
	<div id="footer" role="contentinfo">
		<div id="colophon">
<?php
	/* A sidebar in the footer? Yep. You can can customize
	 * your footer with four columns of widgets.
	 */
	get_sidebar( 'footer' );
?>
			<div id="site-info">
				&#169; <?php echo date('Y'); ?> <?php bloginfo( 'name' ); ?>
			</div><!-- #site-info -->
			<div id="site-generator">
				<?php do_action( 'pupul_credits' ); ?>
				<a href="<?php echo esc_url( __( 'http://pupul.org/', 'pupul' ) ); ?>" title="<?php esc_attr_e( 'WordPress Themes', 'pupul' ); ?>"><?php printf( __( 'Theme by %s', 'pupul' ), 'Pupul' ); ?></a>
			</div><!-- #site-generator -->
		</div><!-- #colophon -->
	</div><!-- #footer -->
</div><!-- #wrapper -->
<?php if (get_option('pupul_analytics_code') != '') { ?>
<?php echo(stripslashes (get_option('pupul_analytics_code')));?>
<?php } ?>
<?php wp_footer();?>
</body>
</html>